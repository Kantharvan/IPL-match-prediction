import csv,collections,json

data={}
data1={}
data2={}
outs=['caught','bowled','lbw']

with open ('deliveriesfinal.csv','r') as f:
	reader = csv.reader(f)
	next(reader)
	for row in reader:
		# row = r.split(',')
		if(row[6],row[8]) not in data.keys():
			data[(row[6],row[8])] = [0]*8
		data[(row[6],row[8])][7] +=1
		if row[15]=='6':
			data[(row[6],row[8])][5]+=1
		elif row[15]=='4':
			data[(row[6],row[8])][4]+=1
		elif row[15]=='3':
			data[(row[6],row[8])][3]+=1
		elif row[15]=='2':
			data[(row[6],row[8])][2]+=1
		elif row[15]=='1':
			data[(row[6],row[8])][1]+=1
		else:
			if row[19] in outs:
				data[(row[6],row[8])][6]+=1
			data[(row[6],row[8])][0]+=1
	# print(row[6],row[8])
	# print(data[(row[6],row[8])])
# 	f.close()
# print(type(data))
# data2 = dict(data.sorted(data.items()))
# print(data)
a=[]
for k,v in data.items():
	l=[]
	l.append(k[0])
	l.append(k[1])
	for i in range(0,7):
		# print(i,k[0])
		# print(data[k])
		# print(data[k][7])
		l.append(float(data[k][i]/data[k][7]))
	l.append(data[k][7])
		# print(l)
	a.append(l)

with open('pvpvp.csv','w') as file:
	for x in a:
		for c in x:
			file.write(str(c)+',')
		file.write('\n')
		




