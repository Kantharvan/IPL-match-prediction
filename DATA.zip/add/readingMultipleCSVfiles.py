import csv, os, time 
def timer(func):
    def wrapperfunction(*args):
        start = time.time()
        func(*args)
        end = time.time()
        print ('Time taken:',end-start)
    return wrapperfunction


data = {}

@timer
def readFiles():
    outs=['caught','bowled','lbw']
    os.chdir(r'E:\Personal Data\5th Semester\Big Data\Assignment-1\ipl_dataset')
    files=os.listdir()
   #print(files)
    #print(len(files))
    #data=[6s,4s,1,2,3,DB,W,Balls_bowled,P(6),P(4),P(1),P(2),P(3)] #Later on we add: Bowler Vulnerability and Batsman Vulnerability
    #print(files[0])
    count = 0
    for x in range(len(files)):
        with open(files[x],mode='r') as file:
            reader = csv.reader(file)
            next(reader)            
            for row in reader:
                if row[0]=='info':
                    #print('Pass')
                    continue
                #print(len(row))
                #print(row)
                count+=1
                if(row[4],row[6]) not in data.keys():
                    data[(row[4],row[6])] = [0]*8
                data[(row[4],row[6])][-1] +=1 #Number of balls faced
                if row[7]=='6':
                    data[(row[4],row[6])][0]+=1
                elif row[7]=='4':
                    data[(row[4],row[6])][1]+=1
                elif row[7]=='1':
                    data[(row[4],row[6])][2]+=int(row[7])#Add to 1/2/3 column
                elif row[7] == '2':
                    data[(row[4],row[6])][3]+=int(row[7])/2
                elif row[7] == '3':
                    data[(row[4],row[6])][4]+=int(row[7])/3
                else:
                    if row[9] in outs:
                        data[(row[4],row[6])][6]+=1 #Add to wicket column
                    data[(row[4],row[6])][5]+=1 #Add to dot ball column
        file.close() 
    print(len(data.items()))
    print(count)

    
@timer        
def BowlerVulnerability():
    for x in data:
        data[x].append((6*data[x][0] + 4*data[x][1] + data[x][2] + data[x][3] + data[x][4])/data[x][-1])

@timer
def BatsmanVulnerability():
    for x in data:
        data[x].append((data[x][6]/data[x][7]))



@timer
def MostVulnerableBatsman():
    
    filtered_data = dict(list(filter(lambda x:x[1][7]>30,data.items())))
    print(len(filtered_data.items()))
    print(sorted(filtered_data,key = lambda x:x[-1],reverse=True)[0])

@timer
def MostVulnerableBowler():
    filtered_data = dict(list(filter(lambda x:x[1][7]>30,data.items())))
    print(sorted(filtered_data,key = lambda x:x[-2],reverse=True)[0])



def writingBackToCSV():
    os.chdir(r'E:\Personal Data\5th Semester\Big Data\Assignment-1')
    with open('condensedIPLdata.csv',mode='w') as file:
        writer = csv.writer(file)
        writer.writerow(['Pair','Sixes','Fours','Ones','Twos','Threes','Dot Balls','Wickets','Total Balls','Bowler Vulnerability','Batsman Vulnerability'])
        for item,val in data.items():
            writer.writerow([(item[0],item[1]),val[0],val[1],val[2],val[3],val[4],val[5],val[6],val[7],val[8],val[9]])
        file.close()




readFiles()
BowlerVulnerability()
BatsmanVulnerability()
(MostVulnerableBatsman()) #Batsman who got out the more times to a bowler per ball bowled
(MostVulnerableBowler())

writingBackToCSV()
